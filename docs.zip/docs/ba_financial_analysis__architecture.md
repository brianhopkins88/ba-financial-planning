# BA Financial Analysis Application – Architecture Specification (v0.9)


**Date:** November 29th, 2025
**Version:** 0.9 (Updated)

---

## 1. Executive Summary

### 1.1 Purpose

This document describes the end‑to‑end architecture for the **BA Financial Analysis** application, a client‑side financial planning tool that helps a household understand whether they can maintain their lifestyle and **avoid running out of money** over a multi‑decade horizon.

The architecture aligns with the current **Requirements Specification** and **User Stories**, and is organized using a classic layered view:

- **Business Architecture** – personas, capabilities, rules, and value.
- **Data Architecture** – core entities, JSON structures, persistence, and lifecycle.
- **Application Architecture** – modules, services, and interactions.
- **Technology Architecture** – platform, tools, non‑functional design.

### 1.2 Scope

This specification covers:

- A single‑user, browser‑based web application (SPA style) with **local storage and JSON file** import/export.
- A **central financial projection engine** that runs entirely in the browser.
- A **modular UI** organized around core planning activities (assumptions, income, expenses, properties, loans, scenarios, dashboards).

It does **not** cover:

- Multi‑user synchronization or collaboration.
- Direct bank / brokerage integrations.
- Regulatory, taxation, or compliance sign‑off for use as a professional financial product.

Whenever this document conflicts with the associated requirements specification or user stories, assume the requirements and user stories are more current. Suggest the architecture be updated as appropriate. 

### 1.3 Key Architectural Decisions

- **Client‑Only First:** All scenario data and calculations run locally in the browser. This minimizes privacy and hosting complexity, and makes the tool portable.
- **Scenario‑Centric Model:** Everything is scoped to a **Scenario** object that includes a snapshot of assumptions, people, assets, liabilities, and outputs. Scenarios are serializable to and from JSON.
- **Single Projection Engine:** All financial logic (cash‑flow waterfall, investment returns, inherited IRA timelines, home equity, reverse mortgage behavior) is implemented in a single, testable **Financial Engine** module.
- **Global Date & Time Navigation:** A **Time Machine** in the app shell controls the current model month/year and drives all visualizations.
- **No Hard‑Coded Financial Constants:** All rates and threshold values are configurable in an **Assumptions** set within each scenario (e.g., inflation, property tax caps, investment returns, insurance growth, minimum cash thresholds).

### 1.4 Major Risks & Mitigations

- **Risk: Complexity Creep in the Engine**  
  As more rules (taxes, additional accounts, government programs) are added, the Financial Engine could become difficult to test or change.
  - **Mitigation:** Keep a strict separation between **core engine logic** and configuration/rules; enforce unit tests for each feature; document calculation steps.

- **Risk: Performance for Long Horizons**  
  Monthly projections over 5+ years plus annual projections for decades could become sluggish on low‑power devices.
  - **Mitigation:** Use efficient data structures, avoid unnecessary object churn, and allow tuning of horizon length in assumptions.

- **Risk: Misinterpretation of Outputs**  
  Users might treat outputs as professional financial advice.
  - **Mitigation:** Clear disclaimers in the UI; emphasize that it is a planning tool for **what‑if** experiments, not regulated financial advice.

### 1.5 High‑Level Architecture Diagrams

#### 1.5.1 System Context (C4 Level 1)

```mermaid
C4Context
    title BA Financial Analysis – System Context

    Person(user, "Household Planner", "Individual or couple planning retirement and housing decisions")

    System(baApp, "BA Financial Analysis App", "Browser-based financial planning tool that runs entirely on the client.")

    System_Ext(jsonFiles, "Scenario JSON Files", "Scenario and profile JSON exports/imports on the local file system.")

    Rel(user, baApp, "Uses via web browser")
    Rel(baApp, jsonFiles, "Reads/Writes", "JSON import/export")
```

#### 1.5.2 Container View (C4 Level 2)

```mermaid
C4Container
    title BA Financial Analysis – Container View

    Person(user, "Household Planner")

    System_Boundary(app, "BA Financial Analysis App") {
        Container(ui, "SPA UI", "TypeScript/React (example)", "Renders modules, scenarios, and charts")
        Container(engine, "Financial Engine", "TypeScript Module", "Runs projections and applies financial rules")
        Container(persistence, "Persistence Service", "TypeScript Module", "Manages localStorage and JSON import/export")
        Container(model, "Scenario Domain Model", "TypeScript Classes/Types", "Core entities: Scenario, Accounts, Properties, Loans, Profiles")
    }

    System_Ext(browserStorage, "Browser Storage", "localStorage / IndexedDB")
    System_Ext(fileSystem, "Local File System", "User’s device for JSON files")

    Rel(user, ui, "Interacts with via browser")
    Rel(ui, engine, "Requests projections", "Scenario JSON")
    Rel(engine, model, "Reads/Writes domain data")
    Rel(ui, persistence, "Save / Load / Export / Import")
    Rel(persistence, browserStorage, "Stores scenarios")
    Rel(persistence, fileSystem, "Reads/Writes", "JSON files")
```

---

## 2. Business Architecture

### 2.1 Business Goals

- Enable a household to:
  - Understand **whether their assets, income, and home equity can support their lifestyle** over their planning horizon.
  - Explore **what‑if scenarios** across employment, housing, and spending decisions.
  - Avoid **running out of money** before expected end‑of‑life.

- Provide:
  - A **transparent model** where all assumptions are visible and editable.
  - A **shareable artifact** (Scenario JSON) for discussion with advisors and partners.

### 2.2 Personas

- **Primary Planner (Owner)**  
  Creates and edits scenarios, maintains assumptions, explores what‑ifs.

- **Partner / Co‑Planner**  
  Reviews and adjusts a subset of inputs (e.g., FTE, retirement timing, discretionary spending).

- **Advisor / Reviewer**  
  Loads scenario JSON, clones and tweaks assumptions (for more conservative or aggressive versions), and walks through outputs with clients.

### 2.3 Business Capabilities

1. **Scenario‑Based Planning**  
   - Define multiple independent scenarios per household.
   - Clone, rename, and export/import scenarios.

2. **Income & Work‑Status Modeling**  
   - Represent changing FTE over time for each person.
   - Model salary, bonuses, and other income streams.

3. **Expense & Lifestyle Modeling**  
   - Represent recurring household expenses, including mortgage, HOA, utilities, insurance, and fun money by age.
   - Add one‑time or episodic big‑ticket expenses (e.g., RV purchase, major travel).

4. **Asset & Liability Management**  
   - Model cash, investments, inherited IRA, retirement accounts.
   - Model mortgages, HELOC, other loans, and **system‑generated reverse mortgage**.

5. **Property & Housing Planning**  
   - Model current and future homes, their appreciation, and LTV constraints.
   - Evaluate new construction, purchases, and future downsize moves.

6. **Projection & Risk Detection**  
   - Generate time‑phased projections with:
     - Cash‑flow waterfall rules.
     - Investment returns that taper with age.
     - Inherited IRA depletion within 10 years.
     - Reverse mortgage when cash buffers deplete.
   - Flag red‑zones where cash buffers or equity become critically low.

### 2.4 Business Rules (Highlights)

- **Scenario Assumptions**  
  - All financial parameters (inflation, investment returns, medical inflation, property insurance growth, property tax cap, etc.) are scenario‑scoped and editable.

- **Investment Return Tapering**  
  - For each person, an initial portfolio return (e.g., 7%) gradually tapers to a lower, more conservative return (e.g., 3.5%) by a target age (e.g., 80).
  - The Financial Engine applies this taper to the joint investment account and other applicable investment vehicles.

- **Cash‑Flow Waterfall**  
  When monthly/annual expenses exceed income, deficits are covered in this order:
  1. **Cash / Joint Accounts** (cash then joint investment).
  2. **Inherited IRA** (within 10‑year rule, accelerated as needed).
  3. **401k / 403b** (subject to age‑based tax assumptions).
  4. **Reverse Mortgage Line of Credit** (if primary home has sufficient equity).

- **Reverse Mortgage & Forced Sale**  
  - Reverse mortgage may be automatically created when cash buffers fall below a minimum threshold.
  - Forced sale of the home can occur when:
    - LTV crosses a threshold.
    - Reverse mortgage + other loans exceed safe equity.

- **Property Appreciation & Costs**  
  - Per‑property appreciation curve varies by age of the home (new, mid, mature).
  - Property tax increases are capped (e.g., 2% per year); property insurance uses a separate growth rate.

---

## 3. Data Architecture

### 3.1 Conceptual Data Model

**Core entities:**

- **Scenario** – Top‑level entity that contains everything for a single plan.
- **Person** – Each household member with birth year, retirement assumptions, and FTE patterns.
- **Profile** – Time‑phased template for income or expenses that can be reused across scenarios.
- **Account** – Cash, joint investment, inherited IRA, 401k/403b, and other accounts.
- **Property** – Real estate asset (home), linked to loans and subject to appreciation rules.
- **Loan** – Mortgage, HELOC, reverse mortgage, or other fixed/revolving debt.
- **ExtraExpense** – One‑off or episodic expenses (e.g., remodel, college funding).
- **ProjectionRow** – Time‑series data for one period (month/year) in a scenario projection.
- **EventLogEntry** – Annotated event (e.g., “Inherited IRA depleted in 2035,” “Reverse Mortgage created in 2038”).

#### 3.1.1 Entity Relationship (Conceptual)

```mermaid
erDiagram
    SCENARIO ||--o{ PERSON : includes
    SCENARIO ||--o{ PROFILE : uses
    SCENARIO ||--o{ ACCOUNT : owns
    SCENARIO ||--o{ PROPERTY : owns
    SCENARIO ||--o{ LOAN : manages
    SCENARIO ||--o{ EXTRA_EXPENSE : includes
    SCENARIO ||--o{ PROJECTION_ROW : produces
    SCENARIO ||--o{ EVENT_LOG_ENTRY : records

    PROPERTY ||--o{ LOAN : "secured by"
    PROFILE ||--o{ PERSON : "applies to (for income)"
```

### 3.2 Logical JSON Structures

#### 3.2.1 Scenario JSON (High Level)

```json
{
  "scenarioMetadata": {
    "id": "uuid",
    "name": "Base Scenario",
    "description": "Stay in current home, retire at 67",
    "createdAt": "2025-11-29T00:00:00Z",
    "updatedAt": "2025-11-29T00:00:00Z",
    "version": 1
  },
  "assumptions": {
    "inflationRate": 0.025,
    "medicalInflationRate": 0.04,
    "propertyTaxCapRate": 0.02,
    "propertyInsuranceGrowthRate": 0.05,
    "initialInvestmentReturn": 0.07,
    "terminalInvestmentReturn": 0.035,
    "terminalInvestmentReturnAge": 80,
    "minCashBuffer": 25000,
    "projectionStartMonth": "2026-01"
  },
  "people": [
    {
      "id": "personA",
      "name": "Person A",
      "birthYear": 1965,
      "retirementAge": 67,
      "fteSchedule": [ /* year -> FTE */ ]
    },
    {
      "id": "personB",
      "name": "Person B",
      "birthYear": 1965,
      "retirementAge": 65,
      "fteSchedule": [ /* year -> FTE */ ]
    }
  ],
  "profiles": {
    "incomeProfiles": [ /* reusable income templates */ ],
    "expenseProfiles": [ /* reusable expense templates */ ]
  },
  "accounts": {
    "cash": { /* balances & rules */ },
    "jointInvestment": { /* balances & rules */ },
    "inheritedIra": { /* balances & depletion rules */ },
    "retirementAccounts": [ /* 401k/403b etc. */ ]
  },
  "properties": [
    {
      "id": "home1",
      "label": "Current Home",
      "zipCode": "92129",
      "buildYear": 2018,
      "initialValue": 1500000,
      "appreciationProfile": "newMidMature",
      "sellPlan": {
        "plannedSellYear": null,
        "forcedSaleLtvThreshold": 0.85
      },
      "loans": ["mortgage1", "heloc1"]
    }
  ],
  "loans": [
    {
      "id": "mortgage1",
      "type": "fixedMortgage",
      "propertyId": "home1",
      "originalBalance": 480000,
      "interestRate": 0.0525,
      "termMonths": 180,
      "extraPrincipalSchedule": [ /* month -> extra payment */ ]
    }
  ],
  "extraExpenses": [ /* one-off & episodic expenses */ ],
  "projection": {
    "frequency": "monthlyThenAnnual",
    "rows": [ /* ProjectionRow */ ]
  },
  "eventLog": [ /* EventLogEntry */ ]
}
```

*(Field names and structures are illustrative; implementation can adjust details while preserving intent.)*

### 3.3 Data Lifecycle

1. **Create Scenario**  
   - User creates a new scenario with defaults, or clones an existing one.

2. **Edit Scenario**  
   - User edits assumptions, people, profiles, accounts, properties, and loans in module UIs.
   - App validates changes and updates the in‑memory Scenario model.

3. **Run Projection**  
   - User triggers a projection (explicitly, or automatically on change).
   - Financial Engine produces ProjectionRows and EventLogEntries into Scenario.projection and Scenario.eventLog.

4. **Persist Scenario**  
   - Scenario is saved to browser storage via Persistence Service.
   - User may export Scenario as a JSON file.

5. **Import / Load Scenario**  
   - User selects a stored scenario from localStorage or uploads a JSON file.
   - App deserializes and sets as the active Scenario.

### 3.4 Persistence Design

- **Browser Storage (localStorage or IndexedDB)**
  - `scenariosIndex` – array of metadata records (id, name, description, lastModified).
  - `scenario:<id>` – compressed JSON for a single scenario.

- **File Export / Import**
  - JSON file uses the Scenario schema with a version field.
  - On import, if schema versions differ, a migration function adapts data.

---

## 4. Application Architecture

### 4.1 High‑Level Modules

**App Shell / Layout**

- Scenario selector & management (new, clone, delete).
- Global "Time Machine" bar with:
  - Scenario start date display.
  - Current model month/year display.
  - Step forward/back controls with acceleration.
  - Jump‑to‑date selector.

**Core Feature Modules**

1. **Dashboard** – net worth, cash buffers, event timeline, scenario comparison.
2. **Assumptions Manager** – global parameters and rates.
3. **Income Manager** – income sources, FTE schedules, income profiles.
4. **Expenses Manager** – recurring expenses, fun money, one‑off expenses.
5. **Assets & Accounts Manager** – cash, investments, inherited IRA, retirement accounts.
6. **Property & Housing Manager** – properties, mortgages, HELOCs, construction plans.
7. **Loans & Debt Manager** – debt CRUD and payoff strategies.
8. **Scenario I/O Manager** – import/export and scenario list management.

### 4.2 Internal Services and Layers

- **Scenario Store (State Layer)**
  - Central in‑memory representation of the active Scenario.
  - Exposes reactive getters/setters for each module.

- **Financial Engine (Domain Logic Layer)**
  - Pure functions or service object that:
    - Accept a Scenario input.
    - Generate ProjectionRows and EventLogEntries.
    - Respect the projection frequency (monthly first 5 years, annual thereafter).

- **Persistence Service**
  - Encapsulates all interaction with browser storage and file APIs.
  - Provides:
    - `listScenarios`, `loadScenario`, `saveScenario`, `exportScenario`, `importScenario`.

- **Validation & Rules Service**
  - Shared validators for:
    - Date ranges.
    - Rate bounds.
    - Logical consistency (e.g., forced sale thresholds, IRA timelines).

### 4.3 Module Interaction – Example Flow

**Use Case: User changes a loan’s extra principal schedule**

1. User edits the extra principal row in **Loans & Debt Manager**.
2. Loans module updates the Scenario Store.
3. Scenario Store signals that the scenario has changed.
4. App triggers the **Financial Engine** to recompute projections for the full horizon.
5. Engine writes new ProjectionRows and EventLogEntries into the Scenario.
6. Dashboard and other visualizations re‑render based on the updated Scenario Store.
7. Persistence Service saves the updated Scenario to browser storage in the background.

### 4.4 Application Architecture Diagram

```mermaid
flowchart LR
    subgraph UI[UI Layer]
        shell[App Shell & Time Machine]
        dashboard[Dashboard]
        assumptions[Assumptions Manager]
        income[Income Manager]
        expenses[Expenses Manager]
        assets[Assets & Accounts]
        properties[Property & Housing]
        loans[Loans & Debt]
        scenarioIO[Scenario I/O]
    end

    subgraph Domain[Domain & Services]
        store[Scenario Store]
        engine[Financial Engine]
        persist[Persistence Service]
        validate[Validation Service]
    end

    subgraph Infra[Browser Infrastructure]
        localStorage[(Browser Storage)]
        fileSystem[(Local File System)]
    end

    shell --> store
    dashboard --> store
    assumptions --> store
    income --> store
    expenses --> store
    assets --> store
    properties --> store
    loans --> store
    scenarioIO --> store

    store --> engine
    engine --> store

    store --> persist
    persist --> localStorage
    scenarioIO --> persist
    persist --> fileSystem

    store --> validate
```

---

## 5. Technology Architecture

### 5.1 Target Platform

- **Client‑Side Web Application**
  - Modern browser (desktop or tablet) with JavaScript enabled.
  - Hosted as static assets (HTML/CSS/JS) on any static web host.

### 5.2 Reference Technology Stack (Example)

> The architecture is **technology‑agnostic**, but an example stack is provided for concreteness.

- **Language:** TypeScript (preferred) or JavaScript.
- **Framework:** React, Vue, or Svelte (React assumed in examples).
- **Build Tool:** Vite, Webpack, or similar.
- **State Management:** Redux, Zustand, Pinia, or framework‑native store.
- **Charts:** Any modern charting library (e.g., Recharts, Chart.js, or D3 wrapper).

### 5.3 Non‑Functional Requirements

- **Performance**
  - Re‑projection for a 35‑year plan should complete in under ~1 second on a typical laptop.
  - UI updates should feel instantaneous when moving the model month/year.

- **Security & Privacy**
  - All data stored locally in browser storage and user’s own file system.
  - No backend services required for core functionality.

- **Testability**
  - Financial Engine and Validation Service are independent of UI and can be unit tested.
  - Scenario JSON fixtures used for regression tests.

- **Portability**
  - App runs from a static hosting environment or even as a local file set.
  - Future option: wrap in Electron or similar for a desktop‑like experience.

---

## 6. Future Extensions

- **Tax Modeling:** Introduce explicit tax modules with progressive brackets and location‑specific rules.
- **Server Sync (Optional):** Add secure cloud storage for multi‑device access and backup.
- **Multi‑User Collaboration:** Allow advisors to annotate scenarios and share them back.
- **Scenario Templates:** Pre‑built scenarios for common patterns (e.g., “Downsize at 70,” “Retire at 65, part‑time to 70”).

---

This v2.0 architecture spec is intended to be a **stable reference** for design and implementation. Future changes should be managed via versioning, with updates documented in an architecture change log.

